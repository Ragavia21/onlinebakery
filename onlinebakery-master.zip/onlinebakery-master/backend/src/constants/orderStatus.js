export const OrderStatus = {
  NEW: 'NEW',
  PAYED: 'PAYED',
  SHIPPED: 'SHIPPED',
  CANCELED: 'CANCELED',
  REFUNDED: 'REFUNDED',
};
